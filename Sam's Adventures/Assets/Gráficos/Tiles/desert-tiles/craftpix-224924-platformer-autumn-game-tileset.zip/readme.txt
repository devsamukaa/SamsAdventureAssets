Font: cooper black
Download: http://allshrift.ru/font/cooper-black/